const _notifier = require('node-notifier')

window.electron_api = {}

window.electron_api.highlighted = function(data)
{
	console.log("you were highlighted")
	_notifier.notify('Message');	
}

console.log(process.platform)